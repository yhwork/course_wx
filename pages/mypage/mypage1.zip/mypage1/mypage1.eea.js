const events = {
  // 界面事件
  ui: {
    AUDIO_PLAY: null,
    btninputOK: null,
    btninputOKs: null,
    MYHOMEPAGE:null
  }
}
// 写接口名称
const effects = {
  GETALL_CHILD_LIST: null,
  upname: null
}

const actions = {
}

export { events, effects, actions }