// import regeneratorRuntime from '../../lib/runtime'
import {
  EApp,
  EPage,
  PAGE_LIFE
} from '../../../eea/index'
import {
  events,
  effects,
  actions
} from './mypage1.eea'

const that = this;
// const audioPlay = require("../../lib/audioPlay");
class upInput1 extends EPage {
  get data() {
    return {
      selected: true,
      inputMap: {
        currentPage: 1,
        pageSize: 1000
      },
      diaryList: [],
      progress: 0,
      value: ''
    };
  }


  mapPageEvent({
    put
  }) {
    return {
      [PAGE_LIFE.ON_LOAD](option) {

      },
    }
  }
  // 界面ui事件
  mapUIEvent({
    put
  }) {
    return {
      [events.ui.MYHOMEPAGE](e) {
       console.log('点击事件',)
      },
    }
  }
  // 请求
  mapEffect() {
    return {
      // 发送请求
      async [effects.GETALL_CHILD_LIST]() {
        this.$api.child.getChildListByCondition({}).then(res => {
          this.setData({
            childList: res.data.result.childList,
            theindex: res.data.result.childList.length
          })
          // console.log(res.data.result.childList)
        })
      }
    }
  }
}

EApp.instance.register({
  type: upInput1,
  id: 'upInput1',
  config: {
    events,
    effects,
    actions
  }
});