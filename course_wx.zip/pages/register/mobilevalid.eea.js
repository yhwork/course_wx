const events = {
    ui: {

    }
}

const effects = {

}

const actions = {

}

export { events, effects, actions }