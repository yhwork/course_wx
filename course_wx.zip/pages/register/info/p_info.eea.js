const events = {
  ui: {
    CHANGE_AVATAR: null,
    CHANGE_NAME: null,
    CHANGE_GENDER: null,
    CHANGE_GRADE: null,
    VIEW_AREA: null,
    SAVE: null,
    back: null,
  }
}

const effects = {
  GET_GRADE: null,
  SAVE_CHILD: null
}

const actions = {}

export {
  events,
  effects,
  actions
}