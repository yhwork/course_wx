const events = {
    ui: {
        OPE_ABSENT: null,
        OPE_CHANGE: null,
        OPE_DEL: null,
        OPE_REMEDIAL: null,
        CHANGE_BEGINDATE: null,
        OPEN_LOCATION: null,
        SHOW_SHARE: null,
        HIDE_SHARE: null
    }
}

const effects = {
    GET_USER_INFO: null,
    GET_CHILD: null,
    GET_LESSON_DETAIL: null,
    UPDATE_LESSON: null,
    DEL_LESSON: null,
    GET_USER_INFO: null,
}

const actions = {
}

export { events, effects, actions }