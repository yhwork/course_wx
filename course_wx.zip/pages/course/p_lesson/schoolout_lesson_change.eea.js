const events = {
    ui: {
        CHANGE_BEGINDATE: null,
        CHANGE_BEGINTIME: null,
        CHANGE_ENDTIME: null,
        SAVE: null,
        CALENDAR_DAY_CHANGED: null,
    }
}

const effects = {
    GET_USER_INFO: null,
    GET_CHILD: null,
    GET_LESSON_DETAIL: null,
    UPDATE_WEEKDAY: null,
    SAVE: null,
}

const actions = {
}

export { events, effects, actions }