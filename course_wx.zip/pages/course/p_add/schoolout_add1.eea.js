const events = {
  ui: {
    CHANGE_NAME: null,
    CHANGE_ORGNAME: null,
    CHANGE_CLASSROOM: null,
    CHANGE_TEACHER: null,
    CHANGE_TEL: null,
    SELECT_ADDRESS: null,
    SAVE_NEXT: null,
    ISSHOW: null,
    CHANGE_LOGO: null,
    CHOOSE_CHILD: null,
    TAB_CLICK: null,
    uploadclassPhoto: null,
    PREVIEW: null,
    SHOWWRON: null,
    BIND_LONG_PRESS: null,
    BIND_COURSE: null,
    BIND_COURSE_DOUBLE: null,
    CHOOSE_TAG: null,
    SAVE_NEXT: null,
    ADD_TAG: null,
    DEL_TAG: null,
    EDIT_TAG: null,
    BIND_SWITCH: null,
    ADD_COURSE_CIRCLE: null,
    CHANGE_CLASSNAME: null,
    chooseSchool: null,
    SELECT_CLASS: null,
    chooseClass: null,
    SURE: null,
    INPUTNAME: null,
    SELECT_XN_CLASS: null,
    INPUTNAME: null,
    SELECT_XN_CLASS: null,
    cancel: null,
    handler: null,
    chargeTab:null,
    CREATE_COURSE:null,
  }
}

const effects = {
 
  GET_USER_INFO: null,
  GET_CHILD: null,
  SAVE_NEXT: null,
  SAV_NEXT: null,
  GET_CLASS_INFO: null,
  LOAD_CHILDALL: null,
  getChildSchoolName: null,
  getAllInternalCourseName: null,
  getClassList: null,
  HAVE_COUSER: null,
  addInternalCourseImg:null,
}

const actions = {}

export {
  events,
  effects,
  actions
}