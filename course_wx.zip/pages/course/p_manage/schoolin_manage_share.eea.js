const events = {
  ui: {
    CHOOSE_CHILD:null,
    ADD_COURSE:null,
    
  }
}

const effects = {
  GET_USER_INFO:null,
  LOAD_CHILDALL:null,
  IMPORT_COURSE:null,
  GETCourseDetails:null,

}

const actions = {}

export {
  events,
  effects,
  actions
}