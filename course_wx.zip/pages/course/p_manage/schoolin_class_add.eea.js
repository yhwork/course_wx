const events = {
  ui: {
    VIEW_AREA:null,
    CHANGE_TIMEFIRST:null,
    CHANGE_BEGINDATE:null,
    CALENDAR_DAY_CHANGED:null,
    CHANGE_TIMEEND:null,
    CHANGE_DURATION: null,
  }
}

const effects = {

}

const actions = {}

export {
  events,
  effects,
  actions
}