const events = {
  ui: {
    shrink:null,
    TAB_CLICK:null,
    CHOOSE_TAG:null,
    BIND_SWITCH:null,
    BIND_COURSE:null,
    ADD_COURSE_CIRCLE:null,
    BIND_COURSE_DOUBLE:null,
    ADD_TAG:null,
    BIND_LONG_PRESS:null,
    DEL_TAG:null,
    EDIT_TAG:null,
    CALENDAR_DAY_CHANGED:null,
    CHANGE_BEGINDATE: null,
    CHANGE_TIMEFIRST: null,
    CHANGE_REMIND: null,
    SAVE_NEXT: null,
    CHANGE_CLASSTIME:null,
    SET_SCHOOLOUT: null,
    chooseSchool: null,
    chooseClass:null,
    CHANGE_TIMEFIVE:null,
    CHANGE_CLASSNAME:null,
  }
}

const effects = {
  UPDATE_WEEKDAY: null,
  CHANGE_ENDDATE: null,
  SAVE_NEXT: null,
  GET_USER_INFO: null,
  GETCourseDetails:null,
  GET_CLASSLIST:null,
}

const actions = {
}

export { events, effects, actions }