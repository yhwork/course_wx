const events = {
    ui: {
        CALENDAR_MONTH_CHANGED: null,
        CHANGE_SELECT: null,
    }
}

const effects = {
    GET_USER_INFO: null,
    GET_CHILD: null,
    GET_COURSE_BY_ID: null,
    GET_CHECKWORK: null,
}

const actions = {
}

export { events, effects, actions }