const events = {
  ui: {
    OPE_EDIT: null,
    OPE_DEL: null,
    SHOW_SHARE:null,

  }
}

const effects = {
  GET_USER_INFO: null,
  GETCourseDetails:null,
  DEL_INTERNALCOURSE:null,
}

const actions = {}

export {
  events,
  effects,
  actions
}