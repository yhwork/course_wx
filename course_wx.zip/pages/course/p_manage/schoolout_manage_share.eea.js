const events = {
    ui: {
        CHOOSE_CHILD: null,
        OPEN_LOCATION: null,
        CLOSE_LAYER: null,
        VIEW_LESSON_DETAIL: null,
        ADD_COURSE: null,
        SURE_LAYER:null,
    }
}

const effects = {
    GET_USER_INFO: null,
    GET_COURSE_BY_ID: null,
    LOAD_CHILDALL: null,
    IMPORT_COURSE: null
}

const actions = {
}

export { events, effects, actions }