const events = {
  ui: {
    GoSetClass:null,
    GO_MYCLASS:null,
    addClass:null,
    searchClass:null,
    changeChild:null,
    choose:null,
    formSubmit:null,
    GO_CLASSMSG_LIST:null
  }
}

const effects = {
  USERINFO:null,
  GET_CLASS:null,
  GET_CLASSLIST:null,
  ADDFOEMID: null,
  GETMESSAGE: null,
}

const actions = {
  HANDLE_ACTION: null,
}

export { events, effects, actions }