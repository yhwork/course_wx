const events = {
  ui: {
    ADDNAME: null,
    ADDSUBJECT: null,
    SELECT_LEVEL3: null
  }
}

const effects = {
  ADDSUBJECT: null
}

const actions = {

}

export { events, effects, actions }