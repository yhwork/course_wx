const events = {
  ui: {
    courseDetail: null,
    tab:null
  }
}

const effects = {
  getCurrentCommunityRule: null
}

const actions = {
}

export { events, effects, actions }