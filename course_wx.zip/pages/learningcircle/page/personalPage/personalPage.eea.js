const events = {
  ui: {
    focus:null,
    nextPage : null, // 下一页
    HOMEPAGE:null
  }
}

const effects = {
  loadUserInfo:null,
  updateFocusStatus:null,
}

const actions = {
}

export { events, effects, actions }