const events = {
  ui: {
    switch1Change:null,
  }
}

const effects = {
  getCurrentCommunityRule:null
}

const actions = {
}

export { events, effects, actions }