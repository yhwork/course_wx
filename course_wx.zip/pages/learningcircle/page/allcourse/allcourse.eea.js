const events = {
  ui: {
    opencourse:null,
    showall:null,
    passindex:null


  }
}

const effects = {
  
 
}

const actions = {
}

export { events, effects, actions }