const events = {
  ui: {
    privacySetBind:null,
    repairClockSetBind: null,
    signDateTimeSetBind:null,
    signWarnTimeRuleBind:null,
    diaryRuleSetBind:null,
  }
}

const effects = {
  
}

const actions = {
}

export { events, effects, actions }