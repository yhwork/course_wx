const events = {
  ui: {
    reasonSelect: null,
    submitBtn:null, // 提交按钮
    bindinput:null, // 文本区域
    
  }
}

const effects = {
  submitComplain: null,
}

const actions = {
}

export { events, effects, actions }