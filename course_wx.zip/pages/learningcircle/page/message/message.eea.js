const events = {
  ui: {
    message_info: null,

  }
}

const effects = {
  load_message_list: null,
  updateUnreadMessageInfo:null,
}

const actions = {}

export {
  events,
  effects,
  actions
}