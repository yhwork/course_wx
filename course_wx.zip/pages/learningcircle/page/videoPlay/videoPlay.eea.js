const events = {
  ui: {
    PLAY_END:null,//播放结束事件
    STOP_PLAY:null
  }
}

const effects = {
  PLAY:null
}

const actions = {}

export {
  events,
  effects,
  actions
}