const events = {
  ui: {
    bindTimeChange:null
  }
}

const effects = {
  saveRemindTime: null,
  getCurrentCommunityRule:null
}

const actions = {
}

export { events, effects, actions }