const events = {
  ui: {
    SHOW_HIDE_C: null,
    CHANGE_TAB: null,
  }
}

const effects = {
  LOAD_CIRCLE_INFO: null,
  LOAD_CIRCLE_MEM: null,
  SAVE_CHILD: null
}

const actions = {
}

export { events, effects, actions }