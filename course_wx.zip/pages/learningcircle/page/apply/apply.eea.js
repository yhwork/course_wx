const events = {
  ui: {
    stopOther: null,
    showClocker: null,
    closeClocker: null,
  }
}

const effects = {
  LOAD_CHILD: null,
  SAVE_CHILD: null,
  saveMyCircle: null,
}

const actions = {
}

export { events, effects, actions }