const events = {
  ui: {
    CALENDAR_MONTH_CHANGED:null,
    daka : null
    
  }
}

const effects = {
  getSignRecordInfo: null,
  getSignInStatisticsByCondition:null,
}

const actions = {
  
}

export { events, effects, actions }