const events = {
  ui: {
    AUDIO_PLAY: null,
    AUDIO_STOP: null,
    AUDIO_UPDATA_PROGRESS: null,
    AUDIO_PLAY_END: null,
    diaryMsg: null,
    moreVISIT:null,
    bindPhotoJump:null
  }
}

const effects = {

  Load_MyPage_For_Parent:null,
  loadUserInfo:null,
  GETMYCIRCLE:null,
  ADDVISIT:null,
  GETALL_DIARY_LIST: null
}

const actions = {
  
}

export { events, effects, actions }