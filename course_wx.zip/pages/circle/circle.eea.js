const events = {
  ui: {
    changeRole: null,
    gotodetailitem:null,
    stopPageScroll:null,
    choseItem:null,
    gotoExam:null,
    adError:null,
  }
}

const effects = {
  LOAD_COMMUNITY_LIST: null,
  getStoreProductHotList:null,
  getChildListByCondition:null

 
  
}

const actions = {}

export {
  events,
  effects,
  actions
}