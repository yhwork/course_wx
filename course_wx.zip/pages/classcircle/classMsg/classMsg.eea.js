const events = {
  ui: {
    CHOOSETYPE:null,
    classManage:null,
    shareTEARCH: null,
    shareHOME: null,
    reportMsg: null,
    showClocker:null,
    JIOND:null,
    PLAYVIDEO:null,
    overVIDEO:null,
    SETLOGO:null,
    inputName:null,
    inputsubject:null,
    SAVEJOIN:null,
    AUDIO_PLAY: null,
    AUDIO_PLAY_END: null,
    AUDIO_UPDATA_PROGRESS: null,
    AUDIO_STOP: null,
    GOWORKINFO:null,
    agreejoin:null,
    PREVIEWIMAGE:null,
    inputStudentId:null,
    CANCELJOIN:null,
    rejectjoin:null,
    TEARCHER_DEL: null,
    outclass:null,
    delclass:null,
    reviseInfo:null,
    SAVE_REVISE_INFO:null,
    SHOW_TEARCHMSG:null,
    mytouchstart:null,
    mytouchend:null,
    ESTOP:null,
    modalCandel:null,
    CANCEL_FOLLOW:null,
    TEARCHERMAG:null,
    formSubmit:null,
    CHOOSUBMITSETYPE:null,
    close_video:null,
    changeRole:null,
  }
}

const effects = {
  USERINFO:null,
  GETNUMBER:null,
  CLASSSTATUS:null,
  GETHOMEWORK:null,
  JOINCLASS:null,
  GETCLASSLIST:null,
  updataStstus:null,
  GETCLASSINFO:null,
  DEL_NOTIFY:null,
  ADDFOEMID: null,

  GETNUMBER:null,
  CLASSSTATUS:null,
  GETHOMEWORK:null,
  JOINCLASS:null,
  GETCLASSLIST:null,
  updataStstus:null,
  GETCLASSINFO:null,
  TEARCHER_DEL_WORK:null,
  GET_NOTIFY:null,
  SHARE_IMG:null,
  CHECK_FOLLOW:null,
  GET_DYNAMICLIST:null,
  DEL_DYNAMIC:null
  
}

const actions = {
}

export { events, effects, actions }