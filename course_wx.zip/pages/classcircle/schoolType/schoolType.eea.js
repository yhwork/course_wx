const events = {
  ui: {
    NAXT:null,
    CHOOSETYPE:null,
    rediochange:null,  // 单选控制
  }
}

const effects = {
  
}

const actions = {
}

export { events, effects, actions }