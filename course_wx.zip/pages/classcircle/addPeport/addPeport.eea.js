 const events = {
   ui: {
     radioChange: null,
     CHANGE_AVATAR: null,
     SET_AUDIO: null,
     START_AUDIO: null,
     STOP_AUDIO: null,
     AUDIO_PLAY:null,
     AUDIO_PLAY_END:null,
     AUDIO_UPDATA_PROGRESS:null,
     AUDIO_STOP:null,
     SET_VIDEO :null,
     cancel:null,
     DELs:null,
     SETHOMEWORK:null,
     SETTITLE:null,
     SETTEXT:null,
     CHOOSECLASS:null,
     PLAYVIDEO:null,
     overVIDEO:null,
     isRemindChange:null,




     SET_VIDEO :null,
     cancel:null,
     DELs:null,
     SETHOMEWORK:null,
     SETTITLE:null,
     SETTEXT:null,
     CHOOSECLASS:null,
     CHOOSE_RECEIPT: null,
     CANCEL_CHOOSE_RECEIPT:null,
     PREVIEWIMAGE:null,
     close_video:null,
     addClass:null,
   }
 }

 const effects = {
   getCLASSLIST: null,
   createHOMEWORK:null,
   USERINFO:null,
   addwork:null,
   create_ClassDynamic:null,
   RECEIPTSUBMIT:null,
   GET_NOTIFY:null,
   GETWORKMSG:null,
 }


 const actions = {}


 export {
   events,
   effects,
   actions
 }