const events = {
  ui: {
    inputvalue:null,
    searchClass:null,
    GO_MYCLASS:null

  }
}

const effects = {
  SEARCHCLASS:null,
  USERINFO:null,
  GETCHILD:null,
}

const actions = {
}

export { events, effects, actions }