const events = {
  ui: {
    CHOOSETYPE:null,
    ADDRECEIPT:null,
  }
}

const effects = {
  GETMSG:null,
  addClassNotify:null

}

const actions = {
}

export { events, effects, actions }