const events = {
  ui: {
    SAVE_NAME:null,
    SAVE_LOGO:null,
    delclass:null,
    saveinputname:null,
    MERGE_CLASS:null,
  }
}

const effects = {
  USERINFO: null,
  GETCLASSINFO: null,
  DELCLASS: null,
  UPCLASSINFO:null,
  updataStstus:null,
  ADDFOEMID:null,
  GETSHAREIMG:null,
}

const actions = {
}

export { events, effects, actions }