const events = {
  ui: {
    SAVE:null,
    setName:null,
    setSchool: null,
    setSubject: null,
    setClassName: null,
    chooseSubject: null,
    chooseSchool:null,
    
  }
}

const effects = {
  USERINFO:null,
}

const actions = {
}

export { events, effects, actions }