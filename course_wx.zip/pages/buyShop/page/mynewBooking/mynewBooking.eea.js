export const events = { //事件
  ui: {
    cans: null,


  }
}

export const effects = { //写接口名称
  getMyAppts: null,//我预约
}


export const actions = { //
  MAP_LESSON_DATA: null,


}