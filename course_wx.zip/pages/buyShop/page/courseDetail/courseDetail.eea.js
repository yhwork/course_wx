export const events = { //事件
  ui: {
    PREV_MONTH: null,
    NEXT_MONTH: null,
    TAP_DAY: null,
  }
}

export const effects = { //写接口名称
  getuserinfo:null
}


export const actions = { //
  MAP_LESSON_DATA: null,
}