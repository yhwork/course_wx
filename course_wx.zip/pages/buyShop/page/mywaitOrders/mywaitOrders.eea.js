const events = {
  ui: {
    copy: null,
    delOrder:null,
    buyagain:null

  
  }
}

const effects = {
  GET_SIGNIN_INFO: null,
  getOrderSnapshotInfo:null,
  deleteStoreOrder:null
 
}

const actions = {}

export {
  events,
  effects,
  actions
}