export const events = { //事件
  ui: {
    cans: null,


  }
}

export const effects = { //写接口名称
  getuserinfo: null
}


export const actions = { //
  MAP_LESSON_DATA: null,


}