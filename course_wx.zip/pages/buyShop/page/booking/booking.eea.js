export const events = { //事件
  ui: {
    bindDateChange: null,
    dayClick:null
  }
}

export const effects = { //写接口名称
  getuserinfo: null,
  getday:null
  
}


export const actions = { //
  MAP_LESSON_DATA: null,
}