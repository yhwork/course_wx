export const events = { //事件
  ui: {
    cans: null,
    endMovie:null,
    beginPlay:null,
    play:null,
    controlVideo: null,
    saveImg:null,
    fullScreen:null,
    goWatch:null
  }
}

export const effects = { //写接口名称
  getHotVideoList: null,
  getHotVideoDetails: null,//去观看视频
  addUserVideoCount:null,//视频次数
  getUserVideoImgList:null // 图片
}


export const actions = { //
  MAP_LESSON_DATA: null,
}