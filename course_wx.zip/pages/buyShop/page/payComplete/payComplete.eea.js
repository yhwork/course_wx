export const events = { //事件
  ui: {
    cans: null,
    gotoIndex:null,
    goodsDetails:null
  }
}

export const effects = { //写接口名称
  getStoreProductGroupPreview:null,
  getProductGroupDetails:null,
  shareInfoRecord:null,
  getCurrentUserInfo:null

}


export const actions = { //
  MAP_LESSON_DATA: null,

}