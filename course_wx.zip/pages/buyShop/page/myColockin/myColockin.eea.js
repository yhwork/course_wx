const events = {
  ui: {
   
  }
}

const effects = {
   getStorePunchToGo: null, //获取打卡详情
  


}

const actions = {}

export {
  events,
  effects,
  actions
}