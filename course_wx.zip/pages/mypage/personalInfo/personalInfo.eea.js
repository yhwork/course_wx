const events = {
  ui: {
    bindNickInput:null,
    bindName:null,
    bindSexInput:null,
    bindAddrInput:null,
    bindSignInput:null,
    bindPhotoChange:null,
    submitChangeInfo:null,
    hideGender:null,
    showGender:null,
    chooseAddr:null,
    bindTeacherClass:null,
    bindTeacherSchool:null,
    bindSchoolInput:null
  }
}

const effects = {
  loadOwnerInfo:null,
  savePersonalInfo:null,
  LOAD_IS_BIND_PHONE:null
}

const actions = {

}

export { events, effects, actions }