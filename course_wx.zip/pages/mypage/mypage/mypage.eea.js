const events = {
  // 界面事件
  ui: {

    stopOther: null,
    showClocker: null,
    closeClocker: null,
    bindAllChild: null,
    bindPhotoJump: null,
    myAttentionBind: null,
    myFansBind: null,
    messageCenterBind: null,
    changeTeacherBind: null,
    bindApplyAuth: null,
    authManageBind: null,
    playHelpBind: null,
    bindClickAdd: null,
    bindMyClass: null,
    seenBind: null,
    myCircle: null,
    myDiary: null,
    MYHOMEPAGE: null,
    accumulatePoints: null,
    myPay: null,
    myallList: null,
    waitpayIntem: null,
    scanCode:null
  }
}
// 接口事件
const effects = {
  
  Load_MyPage_For_Parent: null,
  LOAD_IS_BIND_PHONE: null,
  USER_VISIT: null

}

const actions = {
}

export { events, effects, actions }