const events = {
  ui: {

  }
}

const effects = {
  GETUSERTOTALINTEGRAL: null,
}

const actions = {
}

export { events, effects, actions }