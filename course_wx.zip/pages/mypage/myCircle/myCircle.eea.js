const events = {
  ui: {
    SELECD:null,
    CHOOSE:null,
  }
}

const effects = {
  GETALL_CHILD_LIST: null,
  GETALL_CIRLE_LIST:null,
}

const actions = {
}

export { events, effects,actions }