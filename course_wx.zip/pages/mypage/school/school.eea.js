const events = {
  ui: {
    SELECT_PROVINCE: null,
    SELECT_CITY: null,
    SELECT_REGION: null,
    SHOW_SELECT: null,
    SHOW_INPUT: null,
    HIDE_INPUT: null,
    CLEAR_INPUT: null,
    INPUT_TYPING: null,
    SET_SCHOOL: null,
    inputvalue:null,
    ADDSCHOOL:null,
    INPUTNAME:null,
  }
}

const effects = {
  LOAD_AREA_PROVINCE: null,
  LOAD_AREA_CITY: null,
  LOAD_AREA_REGION: null,
  LOAD_SEARCH: null,
  SEARCH_SCHOOL: null,
  CHANGE_HIDEBOLCK1: null,
  CHANGE_HIDEBOLCK2: null
}

const actions = {

}

export { events, effects, actions }