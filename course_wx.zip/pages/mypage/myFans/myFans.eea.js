const events = {
  ui: {
    attentionOrNot:null,
    PAGEPLUS:null,
    NAVBARTAP: null,
    SELECD: null,
    SELECDS: null,
    fansOrNot: null,
  }
}

const effects = {
  loadMyFansData:null,
  updateCommunityFansStatus:null,
  loadMyAttentionData: null,


}

const actions = {

}

export { events, effects, actions }