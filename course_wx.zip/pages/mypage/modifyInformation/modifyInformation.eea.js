const events = {
  ui: {
    CHANGEPHOTO:null,
    bindNickInput:null,
    bindSexInput:null,
    bindSchoolInput:null,
    saveChildInfo:null,
    showGender:null,
    hideGender:null,
    chooseSchool:null

  }
}

const effects = {
  loadMyChildrenInfo:null,
  saveChildInfo:null,
}

const actions = {

}

export { events, effects, actions }