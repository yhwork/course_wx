const events = {
  ui: {
    focus: null,
    nextPage: null, // 下一页
  }
}

const effects = {
  loadUserInfo: null,
  updateFocusStatus: null,
}

const actions = {
}

export { events, effects, actions }