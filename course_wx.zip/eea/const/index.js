export * from './APP_LIFE'
export * from './PAGE_LIFE'
export * from './COMP_LIFE'