export const events = {
    ui: {
        PREV_MONTH: null,
        NEXT_MONTH: null,
        TAP_DAY: null,
    }
}

export const effects = {
}


export const actions = {
	MAP_MONTHLESSONUM_DATA: null

}