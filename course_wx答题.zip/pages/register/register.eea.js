const events = {
  ui: {
    CHOOSE_ROLE: null,
    CHANGE_ROLE: null,
    getPhoneNumber: null
  }
}

const effects = {
  LOAD_USERINFO: null,
  SET_USERINFO: null,
  CHANGE_ROLE: null,
  updateUserPhoneByWX: null
}

const actions = {

}

export {
  events,
  effects,
  actions
}