const events = {
    ui: {
        CHANGE_TYPE: null,
        CHANGE_NAME: null,
        CHANGE_SCHOOLNAME: null,
        CHANGE_CLASSNAME: null,
        SAVE_NEXT: null,
    }
}

const effects = {
    SAVE_NEXT: null,
    SAVE_TEACHER: null,
}

const actions = {
}

export { events, effects, actions }