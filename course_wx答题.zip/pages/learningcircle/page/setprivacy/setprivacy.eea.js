const events = {
  ui: {
    reasonSelect: null,
    typeLChange:null
  }
}

const effects = {
  getCurrentCommunityRule:null
}

const actions = {
}

export { events, effects, actions }