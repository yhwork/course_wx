const events = {
  ui: {
    dozensOfCards:null,
    diaryUploadAutio:null,
    diaryUploadVideo:null,
    diaryUploadPhoto:null,
    closeActionSheet:null,
    showActionSheet:null,
    shooseAction:null
    
  }
}

const effects = {
  saveDiariesRules:null,
  getCurrentCommunityRule:null,
}

const actions = {

}

export {
  events,
  effects,
  actions
}