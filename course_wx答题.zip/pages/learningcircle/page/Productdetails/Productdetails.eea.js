const events = { //页面事件方法
  ui: {
    gotoTeacher: null,
    gotoorganization:null,
    buy:null
  

  }
}

const effects = { //页面调取接口方法
  saveDiariesRules: null,
  getCurrentCommunityRule: null,
  getCurrentUserInfo:null
}

const actions = {

}

export {
  events,
  effects,
  actions
}