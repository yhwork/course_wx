const events = {
  ui: {
    deleteCommunity:null
  }
}

const effects = {

}

const actions = {
}

export { events, effects, actions }