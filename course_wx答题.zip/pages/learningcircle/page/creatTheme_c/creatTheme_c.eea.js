const events = {
  ui: {
    startDateChange:null,
    endDateChange:null
  }
}

const effects = {
  LOAD_CIRCLE_INFO: null,
  SAVE_NEW_CIRCLE_INFO: null
}

const actions = {
}

export { events, effects, actions }