const events = {
  ui: {
    changeTab:null,
    PAGEPLUS:null,
    PAGEMINUS:null,
    REMOVEMEMBER:null,
    bindRefuseUser:null,
    bindAgreeUser:null,
    bindClockCalendar:null
  }
}

const effects = {
  LOAD_CIRCLE_MEM_LIST: null,
  eliminateUser:null,
}

const actions = {
}

export { events, effects, actions }