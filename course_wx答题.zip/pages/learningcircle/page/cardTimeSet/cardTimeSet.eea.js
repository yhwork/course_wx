const events = {
  ui: {
    reasonSelect: null,
    bindTimeChange:null,
    bindTimeChangeEnd: null,
    changeS:null,
    typeLChange:null,
    submitDataBind:null,
    bindEndDateChange: null,
    bindDateChange: null,
  }
}

const effects = {
  LOAD_CHILD: null,
  SAVE_CHILD: null,
  getCommunityRule:null,
}

const actions = {
}

export { events, effects, actions }