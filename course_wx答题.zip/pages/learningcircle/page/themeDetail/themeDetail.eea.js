const events = {
  ui: {
    AUDIO_PLAY: null, // 音频 - 播放
    AUDIO_STOP: null, // 音频 - 播放
    // AUDIO_SLIDER_CHANGE: null, // 音频 - 拖动进度条
    AUDIO_UPDATA_PROGRESS: null, // 音频 - 更新进度条
    AUDIO_PLAY_END: null, //音频 -播放完毕
  }
}

const effects = {
  GET_SUBJECT_INFO: null
}

const actions = {}

export {
  events,
  effects,
  actions
}