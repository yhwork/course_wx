const events = {
  ui: {
    DEL_THEME:null,
    PAGEPLUS:null,
    MARKED:null,
    MARKED1: null
  }
}

const effects = {
  LOAD_THEME_INFO:null,//获取圈子主题列表
  GET_TODAY_SUBJECT: null,//获取进日打卡的列表
  DEL_SUBJECT_STATUS:null//删除主题
}

const actions = {
}

export { events, effects, actions }