const events = {
  ui: {
    cancel_hide_tap:null,
    sure_hide_tap : null,
    selectFirTab: null,
    selectSecTab: null,
    searchCircle: null,
    searchFocus: null,
    searchBlur: null,
    circleInfo:null,
    eStop:null,
    clearLabelTap:null
  }
}

const effects = {
  loadTabList:null,
  loadCircleList: null,
}

const actions = {
}

export { events, effects, actions }