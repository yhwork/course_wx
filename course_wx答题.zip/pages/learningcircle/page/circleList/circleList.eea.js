const events = {
  ui: {
    CIRCLE_INFO:null,
    NEXT:null,
  }
}

const effects = {
  LOAD_RECOMMEND_CIRCLE_LIST:null,
  LOAD_MY_CIRCLE_LIST: null
}

const actions = {
}

export { events, effects, actions }