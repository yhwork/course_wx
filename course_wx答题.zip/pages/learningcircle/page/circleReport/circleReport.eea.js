const events = {
  ui: {
    reasonSelect: null,
    
  }
}

const effects = {
  LOAD_CHILD: null,
  SAVE_CHILD: null
}

const actions = {
}

export { events, effects, actions }