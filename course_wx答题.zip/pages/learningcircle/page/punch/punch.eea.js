const events = {
  ui: {
 
  }
}

const effects = {
  LOAD_PUNCH:null
}

const actions = {}

export {
  events,
  effects,
  actions
}