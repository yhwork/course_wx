const events = {
  ui: {
    tab: null,
    chooseclass:null,
    gotoMap:null,
    passIndex:null,
    passoneIndex:null,
    lastcouse:null,
    reset:null,
    confirm_box:null
  }
}

const effects = {
  LOAD_CHILD: null,
  SAVE_CHILD: null
}

const actions = {
}

export { events, effects, actions }