const events = {
  ui: {
    openModal: null,
    dataChange: null,
    editModel: null,
    closeModel: null,
    ADDCLASS: null,
  }
}

const effects = {
  GET_USER_INFO:null
}

const actions = {}

export {
  events,
  effects,
  actions
}