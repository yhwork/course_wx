const events = {
    ui: {
        TAB_CLICK: null,
        TAB_CLICK_SUB: null,
        CHANGE_LOGO: null,
        CHOOSE_CHILD: null,
        OPE_EDIT: null,
        OPE_DEL: null,
        CALENDAR_MONTH_CHANGED: null,
        CHANGE_CALENDAR: null,
        OPEN_LOCATION: null,
        SHOW_SHARE: null,
        HIDE_SHARE: null,
        nopower:null
    }
}

const effects = {
    GET_USER_INFO: null,
    GET_CHILD: null,
    GET_COURSE_BY_ID: null,
    GET_LESSONS_BY_COURSEID: null,
    GET_CHECKWORK: null,
}

const actions = {
}

export { events, effects, actions }