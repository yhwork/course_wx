const events = {
    ui: {
        OPEN_LOCATION: null
    }
}

const effects = {
    GET_USER_INFO: null,
    GET_SHARE_INFO: null
}

const actions = {
}

export { events, effects, actions }