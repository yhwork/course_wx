const events = {
    ui: {
        BIND_LONG_PRESS:null,
    	BIND_COURSE:null,
        BIND_COURSE_DOUBLE:null,
    	CHOOSE_TAG:null,
        SAVE_NEXT: null,
        ADD_TAG:null,
        DEL_TAG:null,
        EDIT_TAG:null,
        BIND_SWITCH:null,
        ADD_COURSE_CIRCLE:null
    }
}

const effects = {
	ADD_DEFAULT_COURSE:null,
	GET_CHILD:null,
	GET_USER_INFO:null,
    SAVE_NEXT: null,
    getAllInternalCourseName:null,
    getChildSchoolName:null
}

const actions = {
}

export { events, effects, actions }