const events = {
    ui: {
        SAVE_NEXT: null,
      SAVE_BACK: null,
      modalConfirm: null,
      modalCandel: null,
      delShare:null
    }
}

const effects = {
    SAVE_NEXT: null
}

const actions = {
}

export { events, effects, actions }