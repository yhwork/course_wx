const events = {
    ui: {
    	DEL_TAG:null,
        CHANGE_TAGNAME:null,
    	SAVE_TAG:null,
    }
}

const effects = {
	SAVE_TAG:null
}

const actions = {
}

export { events, effects, actions }