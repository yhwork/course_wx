const events = {
    ui: {
        CHANGE_TAGNAME:null,
    	SAVE_TAG:null,
    }
}

const effects = {
	SAVE_TAG:null
}

const actions = {
}

export { events, effects, actions }