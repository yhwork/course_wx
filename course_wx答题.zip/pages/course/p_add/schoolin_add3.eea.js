const events = {
  ui: {
    SAVE_NEXT: null,
    delShare: null,
  }
}

const effects = {
  SAVE_NEXT: null,
  getChildSchoolName: null,
}

const actions = {}

export {
  events,
  effects,
  actions
}