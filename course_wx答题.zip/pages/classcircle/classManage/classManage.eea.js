const events = {
  ui: {
    del_class:null,
    REMOVE_CLASS:null,
    SHARE_CLASS: null,
    REVISE_NAME: null,
    REVISE_LOGO: null,
    MERGE_CLASS:null,
  }
}

const effects = {
  USERINFO: null,
  GETCLASSINFO:null,
  DELCLASS:null,
  SHARE_IMG:null,
}

const actions = {
}

export { events, effects, actions }