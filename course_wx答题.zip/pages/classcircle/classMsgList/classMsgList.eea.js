export const events = {
  ui: {
    GOSKIP:null,
  }
}

export const effects = {
  GETUSRINFO:null,
  getclass_msglist:null,
  updateUnreadMessageInfo:null   // 消息已读
}

export const actions = {}