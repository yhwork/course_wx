const events = {
  ui: {
    PLAYVIDEO: null,
    overVIDEO: null,
    AUDIO_STOP: null,
    AUDIO_UPDATA_PROGRESS: null,
    AUDIO_PLAY_END: null,
    AUDIO_PLAY: null,
    PREVIEWIMAGE: null,
    SUBMIT: null,
    CANCEL_CHOOSE_RECEIPT:null,
    close_video:null,
  }
}

const effects = {
  GETWORKMSG: null,
  getCLASSLIST:null,
  createHOMEWORK:null,
  addClassNotify:null,
  create_ClassDynamic:null,
}

const actions = {
}

export { events, effects, actions }