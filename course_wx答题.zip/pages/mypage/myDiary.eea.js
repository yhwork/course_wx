const events = {
  ui: {
    AUDIO_PLAY: null,
    AUDIO_STOP: null,
    AUDIO_UPDATA_PROGRESS: null,
    AUDIO_PLAY_END: null,
    CHOOSE:null,
    diaryMsg:null,
  }
}

const effects = {
  GETALL_CHILD_LIST:null,
  GETALL_DIARY_LIST: null
}

const actions = {
}

export { events, effects, actions }