const events = {
  ui: {
    bindAddChild:null,
    bindClildEdit:null,
  }
}

const effects = {
  loadMyChildrens:null,
}

const actions = {

}

export { events, effects, actions }