const events = {
  ui: {
    CHANGE:null,
    SHOP:null,

  
  }
}

const effects = {
  GETUSERTOTALINTEGRAL:null,
}

const actions = {
}

export { events, effects, actions }