const events = {
  ui: {
    stopOther: null,
    showClocker: null,
    closeClocker: null,
    dozensOfCards:null,
    closeClockers:null
  }
}

const effects = {
  LOAD_CHILD: null,
  SAVE_CHILD: null,
  saveMyCircle: null,
  loadRelationList:null,
  updateChildShareListAuthority:null,
  deleteChildRelation:null,
  getChildEdit:null,
}

const actions = {}

export { events, effects, actions }