const events = {
  ui: {
    mytouchstart: null,
    mytouchend:null,
    DELSUBJECT: null,
    ADDSUBJECT: null,
    SELECT_REGION: null,
  }
}

const effects = {
  GETSUBJECT: null,
  DEL_NAME:null,
}

const actions = {

}

export {
  events,
  effects,
  actions
}