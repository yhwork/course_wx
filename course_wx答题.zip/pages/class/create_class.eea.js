export const events = {
  ui: {
    CHANGE_AVATAR: null,
    CHANGE_NAME: null,
    CHANGE_SCHOOLNAME: null,
    CHANGE_CLASSNAME: null,
    CHANGE_COURSETYPE: null,
    SAVE: null,
  }
}

export const effects = {
  GET_USER_INFO: null,
  SAVE: null,
}

export const actions = {}