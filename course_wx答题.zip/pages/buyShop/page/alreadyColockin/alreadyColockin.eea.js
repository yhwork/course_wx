const events = {
  ui: {

  }
}

const effects = {
  getMyClockIn: null, //我的打卡



}

const actions = {}

export {
  events,
  effects,
  actions
}