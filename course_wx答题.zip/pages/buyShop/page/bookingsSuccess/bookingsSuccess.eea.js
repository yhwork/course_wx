const events = {
  ui: {
    gotoBooking:null
    
  }
}

const effects = {
  questionnaire: null,
  shareInfoRecord: null   //分享参数


}

const actions = {}

export {
  events,
  effects,
  actions
}