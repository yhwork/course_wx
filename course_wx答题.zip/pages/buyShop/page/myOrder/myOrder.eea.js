export const  events = {    //事件
  ui: {
    next: null,
    prev: null,
    dateChange: null,
    dayClick: null,
    openM:null,
    booking:null,
    next:null,
    prev:null
  }
}

export const effects = { //写接口名称
  getStorePunchToResOrg: null,
  addStorePunchToResOrgBtn:null


}


export const actions = { //
  MAP_LESSON_DATA: null,
}