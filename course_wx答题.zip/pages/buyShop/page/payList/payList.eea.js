export const events = { //事件
  ui: {
    cans: null,
    plus: null,
    showM: null,
    closeM: null,
    stopPageScroll: null,
    attendlist: null,
    closeLi: null,
    choseItem: null,
    payMoneny: null,
    joingroup: null,
    stopPageScroll:null,
    goodsDetails:null

  }
}

export const effects = { //写接口名称
  getuserinfo: null,
  getStoreProductGroupPreview: null,
  addStoreProductGroupHotByNew: null,
  loadMyPageForParent: null,
  addStoreProductGroupHotJoin: null,
  storePayQueryOrder:null,
  getStoreProductHotDetailsByPid: null


}


export const actions = { //
  MAP_LESSON_DATA: null,
}