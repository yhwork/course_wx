const events = {
  // 界面事件
  ui: {
    radioChange:null,
    checkAll:null,
    closetime:null,
    addnum:null
  }
}
// 写接口名称
const effects = {
  GETALL_CHILD_LIST: null,
  upname: null,
  ADREE_OK:null
}

const actions = {
  INIT:null,
  changeinit:null
}

export { events, effects, actions }