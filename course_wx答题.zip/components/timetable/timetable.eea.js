export const events = {
    ui: {
        WEEK_CHANGED: null,
        WEEK_ANI_FINISHED: null,
        TAP_WEEK: null,
        TAP_DAY: null,
        LESSON_DETAIL: null,
        OPEN_LOCATION: null,
    }
}

export const effects = {
}


export const actions = {
    UPDATE_DAYS: null,
    TRIGGER_DATE_CHANGE: null,
    MAP_DATA: null,
    MAP_LESSON_DATA: null,
    init:null,
}